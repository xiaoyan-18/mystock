# MyStock — POS & Inventory

A single-page point-of-sale and inventory app. No build tools, no dependencies —
just HTML, CSS, and JavaScript in one file (`index.html`).

## Run it in VS Code (recommended)

Opening the file directly (double-click) works, but data can behave inconsistently
because browsers treat local `file://` files unreliably for storage. Serving it
through a local address (`http://localhost`) fixes that.

1. Open this folder in VS Code: `File → Open Folder...`
2. Install the **Live Server** extension (by Ritwick Dey) from the Extensions
   panel (`Ctrl+Shift+X` / `Cmd+Shift+X`), search "Live Server".
3. Right-click `index.html` in the file explorer → **Open with Live Server**.
4. Your browser opens automatically at `http://127.0.0.1:5500` — the app is running.

Keep using that same `http://localhost` address every time (don't reopen the raw
file) and your data — products, sales, customers, login session — will stay saved
reliably between visits.

## Alternative: run without any extension

If you have Node.js installed, you can serve it from the terminal instead:

```bash
npx serve .
```

Then open the printed `http://localhost:...` address in your browser.

## Login

The app is gated by a login screen:
- Email: `gojo936070@gmail.com`
- Password: `9360705966`

## Data & backups

All data is saved automatically in the browser's local storage. Go to
**Settings → Backup & Restore** inside the app to export a `.json` backup file,
or import one to restore your data.
